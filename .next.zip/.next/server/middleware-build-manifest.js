globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/79a4d3a40e6dc636.js",
    "static/chunks/ee0d2ec50ca621d5.js",
    "static/chunks/ff07fd46409b0e0a.js",
    "static/chunks/0744f366d5505410.js",
    "static/chunks/137a8f1fcc26b04c.js",
    "static/chunks/turbopack-6f015330da3586c7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];