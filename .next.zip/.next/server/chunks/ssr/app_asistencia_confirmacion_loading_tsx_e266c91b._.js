module.exports=[51905,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=app_asistencia_confirmacion_loading_tsx_e266c91b._.js.map