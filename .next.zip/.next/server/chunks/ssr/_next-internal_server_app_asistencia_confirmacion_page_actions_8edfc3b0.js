module.exports=[34686,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_asistencia_confirmacion_page_actions_8edfc3b0.js.map