module.exports=[90825,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_asistencia_qr_%5Btoken%5D_page_actions_13046c8d.js.map