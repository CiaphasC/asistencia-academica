module.exports=[68848,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_eventos_registro_%5Benlace%5D_page_actions_80b9b136.js.map