module.exports=[17901,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_asistencia_scanner_page_actions_efdf4372.js.map