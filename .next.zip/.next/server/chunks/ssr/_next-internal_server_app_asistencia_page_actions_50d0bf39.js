module.exports=[4795,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_asistencia_page_actions_50d0bf39.js.map