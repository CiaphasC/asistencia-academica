module.exports=[59462,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mallas-cursos_page_actions_1cf1e130.js.map